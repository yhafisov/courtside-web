(() => {
  'use strict';
  const install=document.getElementById('install'),alert=document.getElementById('siteAlert');
  let deferred;
  function notice(message){alert.hidden=false;alert.textContent=message}
  window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();deferred=event;install.hidden=false});
  if(install){install.addEventListener('click',async()=>{if(!deferred)return;deferred.prompt();await deferred.userChoice.catch(()=>{});deferred=null;install.hidden=true})}
  window.addEventListener('appinstalled',()=>{install.hidden=true;notice('Courtside is installed. Open it from your home screen or dock.')});
  if('serviceWorker' in navigator && (location.protocol==='https:'||location.hostname==='localhost'))window.addEventListener('load',()=>navigator.serviceWorker.register('./service-worker.js').catch(()=>{}));
  const installed=window.matchMedia?.('(display-mode: standalone)')?.matches||navigator.standalone;
  const ios=/iPhone|iPad|iPod/.test(navigator.userAgent);
  if(ios&&!installed){notice('Install on iPhone: open in Safari → Share → Add to Home Screen. Video PiP depends on the source and iOS support.')}
  window.addEventListener('online',()=>{if(!ios||installed)alert.hidden=true});
  window.addEventListener('offline',()=>notice('Offline mode: saved favorites and the home screen are available, but live NBA data and streams require internet.'));
})();
