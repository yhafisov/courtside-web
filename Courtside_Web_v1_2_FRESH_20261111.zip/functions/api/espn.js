/* Cloudflare Pages Function: fixed-source, read-only ESPN gateway.
   Runs only when deployed on Cloudflare Pages; GitHub Pages falls back to browser requests. */
const ROOT='https://site.api.espn.com/apis/site/v2/sports/basketball/nba/';
const urls = {
  standings: season=>[
    `https://site.api.espn.com/apis/v2/sports/basketball/nba/standings?season=${season}&seasontype=2`,
    `https://site.web.api.espn.com/apis/v2/sports/basketball/nba/standings?season=${season}&seasontype=2`,
    `${ROOT}standings?season=${season}&seasontype=2`
  ]
};
async function fetchJson(url){
  const response=await fetch(url,{headers:{Accept:'application/json'},cf:{cacheTtl:45,cacheEverything:true},signal:AbortSignal.timeout(11000)});
  if(!response.ok)throw Error('ESPN HTTP '+response.status);
  return response.json();
}
async function attempt(paths){let err;for(const p of paths){try{return await fetchJson(p)}catch(e){err=e}}throw err||Error('ESPN service unavailable')}
function dateKey(d){return d.toISOString().slice(0,10).replaceAll('-','')}
function hasTeam(e,id){return (e?.competitions||[]).some(c=>(c?.competitors||[]).some(t=>String(t?.team?.id)===String(id)))}
async function schedule(id,season){
  const games=new Map(),success=[];
  const add=(raw,overwrite=false)=>{for(const e of raw?.events||[]){if(!hasTeam(e,id))continue;const k=String(e.id||e.date+'|'+e.name);if(overwrite||!games.has(k))games.set(k,e)}};
  await Promise.all([1,2,3].map(async phase=>{
    try{
      const body=await attempt([`${ROOT}teams/${id}/schedule?season=${season}&seasontype=${phase}&limit=500`,`${ROOT}teams/${id}/schedule?season=${season}&seasonType=${phase}&limit=500`]);
      success.push(1);add(body,false);
    }catch(e){}
  }));
  const start=new Date(Date.UTC(season-1,8,15)),end=new Date(Date.UTC(season,6,15)),limit=new Date(Math.min(end.getTime(),Date.now()+14*86400000));
  const spans=[];
  for(let d=new Date(start);d<=limit;d.setUTCDate(d.getUTCDate()+14)){
    const b=new Date(Math.min(limit.getTime(),d.getTime()+13*86400000));spans.push(dateKey(d)+'-'+dateKey(b));
  }
  for(let i=0;i<spans.length;i+=4){
    await Promise.all(spans.slice(i,i+4).map(async date=>{try{const b=await fetchJson(`${ROOT}scoreboard?dates=${date}&limit=500`);success.push(1);add(b,true)}catch(e){}}));
  }
  if(!success.length)throw Error('No season schedule feeds available');
  return {season,events:[...games.values()]};
}
function pickStatKey(key){
  const k=String(key||'').toLowerCase().replace(/[^a-z0-9]/g,'');
  for(const [result,variants] of Object.entries({GP:['gp','gamesplayed'],MIN:['min','mpg','minutespergame','avgminutes'],PTS:['pts','ppg','pointspergame','avgpoints'],REB:['reb','rpg','reboundspergame','avgrebounds'],AST:['ast','apg','assistspergame','avgassists'],STL:['stl','spg','stealspergame'],BLK:['blk','bpg','blockspergame'], 'FG%':['fgpct','fieldgoalpct','fieldgoalpercentage'], '3P%':['3ppct','3ptpct','threepointpercentage'], 'FT%':['ftpct','freethrowpct','freethrowpercentage']}))if(variants.includes(k))return result;
  return null;
}
function statValues(node,depth=0,out={}){
  if(depth>10||!node)return out;
  if(Array.isArray(node)){node.slice(0,130).forEach(v=>statValues(v,depth+1,out));return out}
  if(typeof node!=='object')return out;
  if(/career|totals|postseason/i.test(node.displayName||node.name||''))return out;
  const key=pickStatKey(node.name||node.abbreviation||'');
  if(key){const val=node.displayValue??node.value;if((typeof val==='string'||typeof val==='number')&&String(val).length<30&&out[key]===undefined)out[key]=String(val)}
  if(Array.isArray(node.labels)&&Array.isArray(node.stats)&&node.labels.length===node.stats.length){
    node.labels.forEach((label,i)=>{const k=pickStatKey(label);const val=node.stats[i];if(k&&out[k]===undefined&&(typeof val==='string'||typeof val==='number'))out[k]=String(val)});
  }
  for(const field of ['stats','statistics','splits','categories','groups','items','entries','results','averages'])if(node[field])statValues(node[field],depth+1,out);
  return out;
}
function rosterAthletes(root){
  const seen=new Set(),list=[];
  function rec(node,d=0){if(d>9||!node||list.length>55)return;
    if(Array.isArray(node)){node.forEach(x=>rec(x,d+1));return}
    if(typeof node!=='object')return;
    const p=node.athlete||node;
    if(p.id&&p.displayName&&!seen.has(String(p.id))){seen.add(String(p.id));list.push({id:String(p.id),name:p.displayName,position:p.position?.abbreviation||''})}
    for(const f of ['athletes','items','roster','groups','entries','players'])if(node[f])rec(node[f],d+1);
  }
  rec(root);return list;
}
async function playerstats(id,season){
  const roster=await fetchJson(`${ROOT}teams/${id}/roster?season=${season}`);
  const players=rosterAthletes(roster).slice(0,24);let withStats=0;
  for(let i=0;i<players.length;i+=5){await Promise.all(players.slice(i,i+5).map(async p=>{
    try{
      const data=await attempt([
        `https://site.web.api.espn.com/apis/common/v3/sports/basketball/nba/athletes/${p.id}/stats?season=${season}&seasontype=2`,
        `https://sports.core.api.espn.com/v2/sports/basketball/leagues/nba/seasons/${season}/types/2/athletes/${p.id}/statistics/0`
      ]);
      const metrics=statValues(data);Object.assign(p,metrics);if(metrics.PTS||metrics.REB||metrics.GP)withStats++;
    }catch(e){}
  }))}
  return {season,players,withStats};
}
export async function onRequestGet({request}){
  const search=new URL(request.url).searchParams;
  const type=search.get('type')||'',team=Number(search.get('team')||0),season=Number(search.get('season')||2027),date=search.get('date')||'';
  const validTypes=['scores','standings','playoffs','roster','stats','schedule','fullschedule','playerstats'];
  if(!validTypes.includes(type)||!Number.isInteger(season)||season<2015||season>2100||!Number.isInteger(team)||team<0||team>30||((type==='scores')&&!/^\d{8}$/.test(date))){
    return Response.json({error:'Invalid request'}, {status:400});
  }
  if(!['scores','standings','playoffs'].includes(type)&&team===0)return Response.json({error:'Team required'},{status:400});
  try{
    let result;
    switch(type){
      case 'scores': result=await fetchJson(`${ROOT}scoreboard?dates=${date}&limit=100`);break;
      case 'standings':result=await attempt(urls.standings(season));break;
      case 'playoffs':result=await fetchJson(`${ROOT}scoreboard?dates=${season}&seasontype=3&limit=500`);break;
      case 'roster':result=await fetchJson(`${ROOT}teams/${team}/roster?season=${season}`);break;
      case 'schedule':result=await fetchJson(`${ROOT}teams/${team}/schedule?season=${season}&limit=500`);break;
      case 'stats':result=await attempt([`https://site.web.api.espn.com/apis/common/v3/sports/basketball/nba/teams/${team}/stats?season=${season}&seasontype=2`,`${ROOT}teams/${team}/statistics?season=${season}&seasontype=2`]);break;
      case 'playerstats':result=await playerstats(team,season);break;
      case 'fullschedule':result=await schedule(team,season);break;
    }
    return Response.json(result,{headers:{'Cache-Control': type==='scores'?'public,max-age=25':'public,max-age=60'}});
  }catch(e){return Response.json({error:'NBA data temporarily unavailable'}, {status:502,headers:{'Cache-Control':'no-store'}})}
}
