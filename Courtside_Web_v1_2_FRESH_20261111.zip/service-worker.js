const CACHE='courtside-pwa-v1.2';
const ASSETS=['./','./index.html','./web-bridge.js','./web-player.js','./web-install.js','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png'];
self.addEventListener('install',event=>{
  event.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
  event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch',event=>{
  const req=event.request;
  if(req.method!=='GET'||new URL(req.url).origin!==self.location.origin)return;
  const u=new URL(req.url);
  if(u.pathname.includes('/api/')||u.pathname.includes('/functions/'))return;
  if(req.mode==='navigate'){
    event.respondWith(fetch(req).then(resp=>{if(resp.ok){const clone=resp.clone();caches.open(CACHE).then(c=>c.put('./index.html',clone)).catch(()=>{})}return resp}).catch(()=>caches.match('./index.html')));return;
  }
  event.respondWith(fetch(req).then(resp=>{if(resp.ok){const clone=resp.clone();caches.open(CACHE).then(c=>c.put(req,clone)).catch(()=>{})}return resp}).catch(()=>caches.match(req)));
});
