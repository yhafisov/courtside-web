/* Courtside Web: limited, read-only ESPN data bridge.
   The Android edition used a native fetch bridge; on the web use the
   Cloudflare Pages Function (when deployed there) or try ESPN directly. */
(() => {
  'use strict';
  const BASE = 'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/';
  const cache = new Map();
  const aliases = {GSW:'warriors',NYK:'knicks',NOP:'pelicans',SAS:'spurs',UTA:'jazz',WAS:'wizards'};
  const slugs = ['hawks','celtics','nets','hornets','bulls','cavaliers','mavericks','nuggets','pistons','warriors','rockets','pacers','clippers','lakers','grizzlies','heat','bucks','timberwolves','pelicans','knicks','thunder','magic','76ers','suns','trailblazers','kings','spurs','raptors','jazz','wizards'];
  const codes = ['ATL','BOS','BKN','CHA','CHI','CLE','DAL','DEN','DET','GSW','HOU','IND','LAC','LAL','MEM','MIA','MIL','MIN','NOP','NYK','OKC','ORL','PHI','PHX','POR','SAC','SAS','TOR','UTA','WAS'];
  const teamSlugs = Object.fromEntries(codes.map((c,i)=>[c,slugs[i]]));
  const teamIds = Object.fromEntries(codes.map((c,i)=>[c, [1,2,17,30,4,5,6,7,8,9,10,11,12,13,29,14,15,16,3,18,25,19,20,21,22,23,24,28,26,27][i]]));
  const isCloudflare = (location.hostname.endsWith('.pages.dev') || (!location.hostname.endsWith('.github.io') && !['localhost','127.0.0.1'].includes(location.hostname))) || !!window.COURTSIDE_API_ENDPOINT;
  const cloudEndpoint = window.COURTSIDE_API_ENDPOINT || (location.origin==='null'?'http://localhost/api/espn':new URL('./api/espn', location.href).href);
  const timeout = ms => new AbortController();
  const cleaned = e => e?.message || String(e) || 'Data temporarily unavailable';
  async function json(url, key, maxAge=45000) {
    const prior=cache.get(key||url);
    if(prior && Date.now()-prior.at<maxAge) return prior.value;
    const ctrl=new AbortController();
    const alarm=setTimeout(()=>ctrl.abort(),14500);
    try {
      const resp=await fetch(url,{signal:ctrl.signal,credentials:'omit',cache:'no-store',headers:{Accept:'application/json'}});
      if(!resp.ok)throw new Error('Data service returned '+resp.status);
      if(!String(resp.headers.get('content-type')||'').includes('json'))throw new Error('Data service did not return JSON');
      const value=await resp.json();cache.set(key||url,{at:Date.now(),value});return value;
    } finally {clearTimeout(alarm)}
  }
  async function firstSuccessful(urls,prefix) {
    let fail;
    for (let i=0;i<urls.length;i++) {
      try {return await json(urls[i],prefix+':'+i,90000)} catch(e){fail=e}
    }
    throw fail || new Error('ESPN data unavailable');
  }
  function apiUrl(type,team,season,date) {
    return cloudEndpoint+'?'+new URLSearchParams({type,team:String(team||0),season:String(season||2027),date:String(date||'')});
  }
  async function viaApi(type,team,season,date){
    if(isCloudflare)try{return await json(apiUrl(type,team,season,date),'prox:'+type+':'+team+':'+season+':'+date,type==='scores'?35000:90000)}catch(e){console.warn('Courtside proxy not available, trying ESPN directly',e)}
    return direct(type,team,season,date);
  }
  function eventTeam(event,id){
    return (event?.competitions||[]).some(c=>(c?.competitors||[]).some(t=>String(t?.team?.id||'')===String(id)));
  }
  async function direct(type,team,season,date){
    if(type==='scores')return json(BASE+'scoreboard?dates='+encodeURIComponent(date)+'&limit=100','scores:'+date,28000);
    if(type==='standings')return firstSuccessful([
      'https://site.api.espn.com/apis/v2/sports/basketball/nba/standings?season='+season+'&seasontype=2',
      'https://site.web.api.espn.com/apis/v2/sports/basketball/nba/standings?season='+season+'&seasontype=2',
      BASE+'standings?season='+season+'&seasontype=2'
    ],'standings:'+season);
    if(type==='playoffs')return json(BASE+'scoreboard?dates='+season+'&seasontype=3&limit=500','playoffs:'+season,200000);
    if(type==='roster')return json(BASE+'teams/'+team+'/roster?season='+season,'roster:'+team+':'+season,240000);
    if(type==='schedule')return json(BASE+'teams/'+team+'/schedule?season='+season+'&limit=500','schedule:'+team+':'+season,100000);
    if(type==='stats')return firstSuccessful([
      'https://site.web.api.espn.com/apis/common/v3/sports/basketball/nba/teams/'+team+'/stats?season='+season+'&seasontype=2',
      BASE+'teams/'+team+'/statistics?season='+season+'&seasontype=2'
    ],'stats:'+team+':'+season);
    if(type==='playerstats')return playerStats(team,season);
    if(type==='fullschedule')return fullSchedule(team,season);
    throw new Error('Unsupported data request');
  }
  async function playerStats(team,season){
    // ESPN returns more than one schema; never fill missing stats with invented numbers.
    let roster={};try{roster=await direct('roster',team,season)}catch(e){throw e}
    let stats={};try{stats=await direct('stats',team,season)}catch(e){}
    const people=[];const seen=new Set();
    function visit(x,depth=0){
      if(!x||depth>9||people.length>60)return;
      if(Array.isArray(x)){x.forEach(y=>visit(y,depth+1));return}
      if(typeof x!=='object')return;
      const p=x.athlete||x;
      if(p.id&&p.displayName&&!seen.has(String(p.id))){seen.add(String(p.id));people.push({id:String(p.id),name:p.displayName,position:p.position?.abbreviation||''})}
      for(const field of ['athletes','items','groups','roster','players','entries'])if(x[field])visit(x[field],depth+1);
    }
    visit(roster);
    // Team/player stats vary by provider; return roster honestly if averages aren't exposed.
    return {season,players:people.slice(0,45),withStats:0,provider:'ESPN',hasTeamData:!!Object.keys(stats).length};
  }
  function ymd(d){return d.toISOString().slice(0,10).replaceAll('-','')}
  async function fullSchedule(team,season) {
    const entries=new Map(), successful=[];
    const add=(body,prefer) => {
      for(const e of body?.events||[]){
        if(!eventTeam(e,team))continue;
        const key=String(e.id||e.date+'-'+e.name);
        if(!entries.has(key)||prefer) entries.set(key,e);
      }
    };
    // Separate ESPN calls per season phase; the single team endpoint frequently omits older results.
    const phases=[1,2,3];
    await Promise.all(phases.map(async phase=>{
      const urls=[BASE+'teams/'+team+'/schedule?season='+season+'&seasontype='+phase+'&limit=500',BASE+'teams/'+team+'/schedule?season='+season+'&seasonType='+phase+'&limit=500'];
      try {const body=await firstSuccessful(urls,'phase:'+team+':'+season+':'+phase);successful.push(1);add(body,false)}catch(e){}
    }));
    // Backfill from dated scoreboards. This is especially important early in the season.
    const start=new Date(Date.UTC(season-1,8,15)),end=new Date(Date.UTC(season,6,15)),nearNow=new Date(Date.now()+14*86400000);
    const stop=new Date(Math.min(end.getTime(),nearNow.getTime()));const ranges=[];
    for(let d=new Date(start);d<=stop;d.setUTCDate(d.getUTCDate()+14)){
      const until=new Date(Math.min(stop.getTime(),d.getTime()+13*86400000));
      ranges.push(ymd(d)+'-'+ymd(until));
    }
    // Concurrency of four limits load. Unavailable data remains unavailable.
    for(let i=0;i<ranges.length;i+=4){
      await Promise.all(ranges.slice(i,i+4).map(async range=>{
        try {const body=await json(BASE+'scoreboard?dates='+range+'&limit=500','range:'+range,90000);successful.push(1);add(body,true)}catch(e){}
      }));
    }
    if(!successful.length)throw new Error('Season data could not be retrieved from ESPN. Try again later.');
    return {season,events:[...entries.values()]};
  }
  function notify(call,value,error){if(typeof window[call]==='function')window[call](value,error||null)}
  async function scores(date,today=false){
    try{const value=await viaApi('scores',0,0,date);notify(today?'receiveTodayScores':'receiveScores',value,null)}
    catch(e){notify(today?'receiveTodayScores':'receiveScores',null,'Scoreboard unavailable: '+cleaned(e))}
  }
  function openTeam(team,replay=false,gameId='') {
    const code=String(team||'').toUpperCase();
    const slug=teamSlugs[code]||'schedule';
    const url='https://topstreamer.site/nba/'+slug;
    if(window.CourtsideWeb?.open)window.CourtsideWeb.open(url,{team:code,replay,gameId});
    else window.open(url,'_blank','noopener,noreferrer');
  }
  const Android={
    scores:date=>scores(date,false),todayScores:date=>scores(date,true),
    data(type,team,season,token){viaApi(type,team,season,'').then(v=>window.CourtsideData?.receive(token,v,null)).catch(e=>window.CourtsideData?.receive(token,null,cleaned(e)))},
    openTeam:code=>openTeam(code),openReplay:(code,id)=>openTeam(code,true,id),
    openTeamStats:code=>{
      const slug=teamSlugs[code]||String(code).toLowerCase();
      window.open('https://www.espn.com/nba/team/stats/_/name/'+encodeURIComponent(slug),'_blank','noopener,noreferrer');
    },
    resumeStream:()=>window.CourtsideWeb?.resume?.(),
    openSchedule:()=>window.CourtsideWeb?.open?.('https://topstreamer.site/nba/schedule',{team:'NBA'}),
  };
  window.Android=Android;
  window.CourtsideApi={direct,viaApi,teamSlugs,teamIds,cache};
})();
