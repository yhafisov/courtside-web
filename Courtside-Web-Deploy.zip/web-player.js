/* Courtside Web player. IMPORTANT: cross-origin iframe restrictions are enforced.
   No claim to control hidden player quality, internal feed links, or native sound. */
(() => {
  'use strict';
  const root=document.createElement('div');root.id='csPlayer';root.className='cs-player';root.hidden=true;
  root.innerHTML=`
    <div class="cs-player-top" id="csPlayerTop">
      <button id="csBack" aria-label="Minimize player">‹ <span>Games</span></button>
      <div class="cs-player-label"><b id="csTitle">COURTSIDE</b><small id="csType">Live stream</small></div>
      <div class="cs-top-actions"><button id="csPip" title="Picture-in-picture" aria-label="Picture-in-picture">▣</button><button id="csOpen" title="Open original stream" aria-label="Open original stream">↗</button><button id="csMinimize" title="Minimize" aria-label="Minimize">⌄</button></div>
    </div>
    <div id="csStage" class="cs-stage">
      <div class="cs-surface" id="csSurfaceA"></div><div class="cs-surface cs-second" id="csSurfaceB" hidden></div>
      <button id="csOpenFloating" class="cs-open-floating" title="Open in browser">↗ Open original stream</button>
      <div class="cs-input-layer" id="csTouch" aria-label="Touch video to toggle controls"></div>
      <div class="cs-hint" id="csHint" role="status" aria-live="polite"></div>
      <div class="cs-player-controls" id="csControls">
        <div class="cs-quick-row"><div><span class="cs-dot"></span><b id="csFeedName">STREAM</b></div><button id="csSourceControls">Site controls</button></div>
        <div class="cs-seek" id="csSeekRow" hidden><span id="csElapsed">0:00</span><input type="range" id="csSeek" min="0" max="1000" value="0" aria-label="Seek replay"><span id="csDuration">0:00</span></div>
        <div class="cs-action-row">
          <button id="csTogglePlay" aria-label="Pause or play">Ⅱ <span>Play</span></button>
          <button id="csView" aria-label="Choose video view">◫ <span>Views</span></button>
          <button id="csQuality" aria-label="Video quality">HD <span>Quality</span></button>
          <button id="csFit" aria-label="Toggle fit or fill">▣ <span>Fit</span></button>
          <button id="csDual" aria-label="Dual stream">▥ <span>Dual</span></button>
          <button id="csFull" aria-label="Fullscreen">⛶ <span>Full</span></button>
        </div>
      </div>
    </div>
    <div class="cs-player-notice" id="csNotice">Some sites block embedding. Use ↗ to watch on the original site.</div>
    <div id="csMiniBar" class="cs-mini-bar"><button id="csMiniExpand" aria-label="Expand mini player"><b id="csMiniName">NBA stream</b><span>Tap to expand</span></button><button id="csMiniPip" title="Picture in picture">▣</button><button id="csMiniPause" title="Pause">Ⅱ</button><button id="csMiniClose" title="Close">×</button></div>
    <div id="csDialog" class="cs-dialog" hidden><div class="cs-dialog-card"><header><strong id="csDialogTitle">Views</strong><button id="csDialogClose" aria-label="Close dialog">×</button></header><div id="csDialogBody"></div></div></div>
  `;
  document.body.append(root);
  const css=document.createElement('style');css.textContent=`
  .cs-player{position:fixed;inset:0;z-index:90;display:flex;flex-direction:column;color:#f7faff;background:#03070e;padding-top:env(safe-area-inset-top);font-family:system-ui,-apple-system,Roboto,sans-serif}
  .cs-player[hidden],.cs-player [hidden]{display:none!important}.cs-player button{font:inherit;cursor:pointer;color:inherit;border:1px solid #34445c;background:#172338;border-radius:12px;min-height:40px;padding:8px 13px}.cs-player button:active{opacity:.8}.cs-player-top{display:flex;align-items:center;gap:10px;padding:10px clamp(10px,3vw,22px);flex:0 0 auto;background:#080e19}.cs-player-top>button{background:#1b2b41}.cs-player-label{flex:1;display:flex;flex-direction:column;text-align:center;min-width:0}.cs-player-label b{font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.cs-player-label small{font-size:11px;color:#92a4be}.cs-top-actions{display:flex;gap:6px}.cs-player-top button{height:42px;white-space:nowrap}.cs-player-top #csBack{font-weight:800}.cs-stage{flex:1;display:flex;position:relative;min-height:0;background:#000;align-items:center;justify-content:center;overflow:hidden}.cs-surface{width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:#000;overflow:hidden}.cs-surface iframe,.cs-surface video{display:block;width:100%;height:100%;background:#000;border:0;object-fit:contain;max-height:100%;max-width:100%}.cs-surface iframe{width:min(100%,177.7778dvh);height:min(100%,56.25vw);aspect-ratio:16/9}.cs-player.cs-fill .cs-surface video{object-fit:cover}.cs-player.cs-fill .cs-surface iframe{width:100%;height:100%;aspect-ratio:auto}.cs-player.cs-dual .cs-surface{flex:1;width:50%;min-width:0;height:100%}.cs-player.cs-dual .cs-second{display:flex!important}.cs-player.cs-dual .cs-surface iframe{width:100%;height:auto;max-height:100%;aspect-ratio:16/9}.cs-open-floating{position:absolute;top:14px;left:50%;transform:translateX(-50%);z-index:6;background:#182b42d9!important;font-size:11px!important;min-height:33px!important;white-space:nowrap}.cs-player.cs-mini .cs-open-floating{display:none}.cs-input-layer{position:absolute;inset:0;z-index:2;touch-action:pan-y;cursor:pointer}.cs-player.cs-site-touch .cs-input-layer{pointer-events:none}.cs-player.cs-site-touch .cs-player-controls{pointer-events:none}.cs-player-controls{position:absolute;bottom:0;left:0;right:0;z-index:5;padding:12px clamp(10px,2vw,26px) max(13px,env(safe-area-inset-bottom));background:linear-gradient(transparent,rgba(4,11,21,.88) 22%,rgba(4,11,21,.96));transition:opacity .2s}.cs-player:not(.cs-controls-on) .cs-player-controls{opacity:0;pointer-events:none}.cs-quick-row{display:flex;align-items:center;justify-content:space-between;gap:15px;font-size:10px;color:#cfdae9;margin-bottom:12px;letter-spacing:1px}.cs-quick-row button{font-size:11px;min-height:32px}.cs-dot{width:8px;height:8px;background:#75efb5;display:inline-block;border-radius:50%;margin-right:6px}.cs-action-row{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:8px}.cs-action-row button{min-width:0;background:#182b42;border-color:#293d53;min-height:48px;font-weight:850;font-size:15px;padding:5px}.cs-action-row button span{display:block;font-size:9px;color:#b2c3d9;white-space:nowrap;margin-top:2px}.cs-seek{display:flex;align-items:center;gap:10px;margin:0 0 13px;font-size:11px;color:#a5b6ca}.cs-seek input{flex:1;accent-color:#ff8055;min-width:40px}.cs-player-notice{font-size:10px;text-align:center;color:#92a2b8;padding:7px 12px 10px;background:#080e19}.cs-hint{position:absolute;left:50%;top:15%;transform:translateX(-50%);z-index:7;pointer-events:none;background:#111d2ce6;border:1px solid #38516b;border-radius:24px;color:#fff;padding:9px 14px;font-weight:900;font-size:13px;opacity:0;transition:opacity .15s;white-space:nowrap}.cs-hint.visible{opacity:1}.cs-hint.cs-left{top:50%;left:15%}.cs-hint.cs-right{top:50%;left:85%}.cs-mini-bar{display:none}.cs-player.cs-mini{inset:auto 10px calc(10px + env(safe-area-inset-bottom)) 10px;width:auto;height:102px;border-radius:16px;flex-direction:row;align-items:stretch;overflow:hidden;padding:0;border:1px solid #31465e;box-shadow:0 18px 55px #000b;background:#111e2e}.cs-player.cs-mini .cs-player-top,.cs-player.cs-mini .cs-player-notice,.cs-player.cs-mini .cs-input-layer,.cs-player.cs-mini .cs-player-controls,.cs-player.cs-mini .cs-hint{display:none!important}.cs-player.cs-mini .cs-stage{flex:0 0 min(40vw,180px);height:100%;border-right:1px solid #2c3d50;pointer-events:none}.cs-player.cs-mini .cs-surface iframe,.cs-player.cs-mini .cs-surface video{width:100%;height:100%;aspect-ratio:16/9;object-fit:contain}.cs-player.cs-mini .cs-mini-bar{display:flex;align-items:center;min-width:0;flex:1;gap:5px;padding:8px}.cs-player.cs-mini .cs-mini-bar button{min-width:30px;padding:6px;border:0;background:transparent;font-size:19px;height:100%}.cs-player.cs-mini #csMiniExpand{flex:1;text-align:left;min-width:0;font-size:11px}.cs-player.cs-mini #csMiniExpand span{display:block;color:#8fa4be;font-weight:500;font-size:10px;margin-top:5px}.cs-player.cs-mini #csMiniName{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.cs-dialog{position:fixed;inset:0;background:#000b;z-index:100;display:flex;align-items:center;justify-content:center;padding:16px}.cs-dialog-card{background:#111e2c;border:1px solid #40516b;width:min(100%,520px);max-height:86dvh;overflow-y:auto;border-radius:18px;padding:17px}.cs-dialog-card header{background:transparent;border:0;display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}.cs-dialog-card header strong{font-size:18px}.cs-dialog-card button{margin:5px 0}.cs-dialog-card .cs-dialog-list{display:grid;gap:8px}.cs-dialog-card .cs-dialog-list button{text-align:left}.cs-dialog-card input{width:100%;padding:12px;background:#091525;color:white;border:1px solid #3e526d;border-radius:9px;margin:8px 0}.cs-dialog-card .cs-help{color:#a8bbcf;font-size:12px;line-height:1.6}.cs-dialog-card .cs-warning{color:#ffbc91}.cs-dialog-card .cs-primary{background:#fc8158;color:#07121e;border:0;font-weight:900}.cs-player #csMiniClose{font-size:26px}.cs-dialog-card .cs-controls-option{display:flex;align-items:center;gap:10px;font-size:12px}.cs-controls-option input{width:18px}.cs-player.cs-dual .cs-stage{flex-direction:row}
  @media(min-width:900px){.cs-player:not(.cs-mini){max-width:none}.cs-mini{max-width:610px;left:50%!important;transform:translateX(-50%)}.cs-player-top{padding-inline:30px}}
  @media(max-width:620px){.cs-player .cs-player-top{padding:7px 9px;gap:6px}.cs-player .cs-player-top button{min-height:39px;padding:6px 9px}.cs-player .cs-player-label b{font-size:12px}.cs-action-row{gap:5px}.cs-action-row button{font-size:14px;min-height:46px;border-radius:9px}.cs-action-row button span{font-size:8px}.cs-stage{min-height:130px}}
  @media(orientation:portrait) and (max-width:620px){.cs-player:not(.cs-mini) .cs-stage{flex:1}.cs-action-row{grid-template-columns:repeat(3,minmax(0,1fr))}.cs-player:not(.cs-mini) .cs-stage iframe{width:100%;height:auto;aspect-ratio:16/9}.cs-player.cs-fill:not(.cs-mini) .cs-stage iframe{width:100%;height:100%;aspect-ratio:auto}}
  `;document.head.append(css);
  const $=id=>document.getElementById(id);
  let streamUrl='',streamTeam='',sourceType='iframe',primary=null,second=null,mode='closed',show=true,timer=null,feedKey='',dual=false,siteControls=false,last='',primaryPaused=false,hintTimeout=null,holdTimeout=null,lastTap=0,lastTapX=0,tapTimeout=null,holdActive=false,downX=0,downY=0,gestureMoved=false,originalSpeed=1;
  const surface=$('csSurfaceA'),surfaceB=$('csSurfaceB');
  const SLUGS=window.CourtsideApi?.teamSlugs||{};
  function allowedUrl(url){try{const u=new URL(url);return u.protocol==='https:' || (u.protocol==='http:'&&['localhost','127.0.0.1'].includes(u.hostname))}catch{return false}}
  function videoUrl(url){return /\.(mp4|webm|mov|m3u8)(?:[?#]|$)/i.test(url)||/^[a-z0-9]+:\/\/[^ ]+\.(?:mp4|m3u8)/i.test(url)}
  function feedTitle(){return streamTeam||'NBA STREAM'}
  function hint(message,place=''){const h=$('csHint');h.className='cs-hint visible'+(place?' cs-'+place:'');h.textContent=message;clearTimeout(hintTimeout);hintTimeout=setTimeout(()=>h.className='cs-hint',950)}
  function saved(){try{return JSON.parse(localStorage.getItem('cs_last_stream')||'null')}catch{return null}}
  function save(){localStorage.setItem('cs_last_stream',JSON.stringify({url:streamUrl,team:streamTeam,replay:/replay/i.test($('csType').textContent)}));window.showResume?.(true)}
  function feedList(){try{return JSON.parse(localStorage.getItem('cs_feeds_'+feedKey)||'[]')}catch{return []}}
  function putFeed(name,url){if(!allowedUrl(url))return false;const arr=feedList();if(!arr.some(x=>x.url===url))arr.push({name,url});localStorage.setItem('cs_feeds_'+feedKey,JSON.stringify(arr));return true}
  function pauseAvailable(){return sourceType==='video' && primary instanceof HTMLVideoElement}
  function createMedia(host,url){
    host.replaceChildren();const isVideo=videoUrl(url);
    let el;
    if(isVideo){el=document.createElement('video');el.controls=false;el.playsInline=true;el.setAttribute('playsinline','');el.setAttribute('webkit-playsinline','');el.autoplay=true;el.preload='metadata';el.src=url;el.addEventListener('timeupdate',updateTime);el.addEventListener('loadedmetadata',updateTime);el.addEventListener('error',()=>hint('Video not playable here · Open original site'));
      el.play().catch(()=>hint('Tap Play to start'));
    } else {el=document.createElement('iframe');el.src=url;el.referrerPolicy='strict-origin-when-cross-origin';el.allow='autoplay; fullscreen; picture-in-picture; encrypted-media';el.allowFullscreen=true;el.setAttribute('title','Embedded stream');el.loading='eager';}
    host.append(el);return el;
  }
  function load(url,opts={},newFeed=true){
    if(!allowedUrl(url))return hint('Please enter a valid HTTPS link');
    streamUrl=url;streamTeam=opts.team||streamTeam||'NBA';feedKey=streamTeam||'NBA';sourceType=videoUrl(url)?'video':'iframe';primary=createMedia(surface,url);second?.remove();second=null;dual=false;root.classList.remove('cs-dual');surfaceB.hidden=true;
    $('csOpenFloating').hidden=sourceType==='video';$('csTitle').textContent=feedTitle();$('csMiniName').textContent=feedTitle();$('csType').textContent=opts.replay?'Replay':'Stream';$('csFeedName').textContent=opts.replay?'REPLAY':'STREAM';$('csTogglePlay').disabled=!pauseAvailable();$('csSeekRow').hidden=!pauseAvailable();$('csSourceControls').textContent='Site controls';siteControls=false;root.classList.remove('cs-site-touch');root.classList.remove('cs-fill');$('csFit').querySelector('span').textContent='Fit';
    if(newFeed)save();showControls(true);updateTime();
  }
  function updateTime(){if(!pauseAvailable())return;const v=primary,d=v.duration,fmt=s=>!Number.isFinite(s)?'LIVE':`${Math.floor(s/3600)?Math.floor(s/3600)+':':''}${Math.floor(s%3600/60)}:${String(Math.floor(s%60)).padStart(2,'0')}`;$('csElapsed').textContent=fmt(v.currentTime);$('csDuration').textContent=fmt(d);$('csSeek').disabled=!Number.isFinite(d);if(Number.isFinite(d)&&d>0)$('csSeek').value=Math.round(v.currentTime/d*1000);}
  function showControls(next){show=next;root.classList.toggle('cs-controls-on',show);if(timer)clearTimeout(timer);if(show&&mode==='full')timer=setTimeout(()=>showControls(false),4200)}
  function full(){if(mode==='closed')return;mode='full';root.hidden=false;root.classList.remove('cs-mini');document.body.classList.remove('has-mini');document.body.style.overflow='hidden';showControls(true);$('csControls').hidden=false;}
  function mini(){if(mode==='closed')return;mode='mini';root.hidden=false;root.classList.add('cs-mini');document.body.classList.add('has-mini');document.body.style.overflow='';showControls(false);if(document.fullscreenElement)document.exitFullscreen().catch(()=>{});}
  function close(){mode='closed';root.hidden=true;surface.replaceChildren();surfaceB.replaceChildren();primary=second=null;streamUrl='';dual=false;root.classList.remove('cs-mini','cs-dual','cs-site-touch');document.body.classList.remove('has-mini');document.body.style.overflow='';localStorage.removeItem('cs_last_stream');window.showResume?.(false);if(document.fullscreenElement)document.exitFullscreen().catch(()=>{});}
  function open(url,opts={}){mode='full';root.hidden=false;load(url,opts);full();}
  function resume(){const lastSaved=saved();if(lastSaved?.url)open(lastSaved.url,lastSaved)}
  function sourceControls(){siteControls=!siteControls;root.classList.toggle('cs-site-touch',siteControls);$('csSourceControls').textContent=siteControls?'App controls':'Site controls';if(siteControls)showControls(false);else showControls(true)}
  async function pip(){
    let v=pauseAvailable()?primary:second instanceof HTMLVideoElement?second:null;
    if(!v){hint('PiP needs a compatible video source');dialog('Picture in Picture',body=>{body.innerHTML='<p class="cs-help">For an embedded website, iOS and macOS browsers only permit PiP when the provider enables it. Open the original player and use its Picture-in-Picture control if available.</p>';const b=document.createElement('button');b.textContent='Open original player ↗';b.onclick=()=>window.open(streamUrl,'_blank','noopener');body.append(b)});return}
    try {if(document.pictureInPictureElement){await document.exitPictureInPicture();return}if(v.requestPictureInPicture)await v.requestPictureInPicture();else if(v.webkitSupportsPresentationMode?.('picture-in-picture'))v.webkitSetPresentationMode('picture-in-picture');else hint('PiP not supported by this browser');}
    catch(e){hint('PiP unavailable · try the video controls')}
  }
  function togglePause(){if(!pauseAvailable())return hint('Use site controls to play or pause this embed');if(primary.paused)primary.play().catch(()=>hint('Tap the video to play'));else primary.pause();$('csTogglePlay').firstChild.textContent=primary.paused?'▶':'Ⅱ';$('csMiniPause').textContent=primary.paused?'▶':'Ⅱ';}
  function seek(delta){if(!pauseAvailable()||!Number.isFinite(primary.duration))return;primary.currentTime=Math.max(0,Math.min(primary.duration,primary.currentTime+delta));hint(delta>0?'+10 seconds':'−10 seconds',delta>0?'right':'left');}
  function dialog(title,fill){const d=$('csDialog');$('csDialogTitle').textContent=title;const body=$('csDialogBody');body.replaceChildren();fill(body);d.hidden=false;showControls(true)}
  function closeDialog(){$('csDialog').hidden=true}
  function elem(tag,text,cls){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e}
  function action(text,fn,cls=''){const b=elem('button',text,cls);b.addEventListener('click',fn);return b}
  function showViews(){dialog('Choose a view',body=>{
    const list=elem('div',undefined,'cs-dialog-list');
    list.append(action('Original page',()=>{closeDialog();load('https://topstreamer.site/nba/'+(SLUGS[streamTeam]||'schedule'),{team:streamTeam,replay:/replay/i.test($('csType').textContent)})}));
    for(const f of feedList())list.append(action(f.name||f.url,()=>{closeDialog();load(f.url,{team:streamTeam,replay:/replay/i.test(f.name)})}));
    body.append(list,elem('p','Browsers cannot read feed buttons inside another website’s cross-origin player. You can save additional view URLs here or open the original site to select them.','cs-help'));
    const field=elem('input');field.type='url';field.placeholder='https://… direct video or embed URL';field.setAttribute('aria-label','New view URL');body.append(field);
    const title=elem('input');title.placeholder='View name (e.g. Home feed)';title.setAttribute('aria-label','New view name');body.append(title);
    body.append(action('Save & play view',()=>{if(putFeed(title.value.trim()||'Custom view',field.value.trim())){closeDialog();load(field.value.trim(),{team:streamTeam,replay:/replay/i.test(title.value)})}else hint('Use a valid HTTPS URL')},'cs-primary'));
  })}
  function quality(){dialog('Video quality',body=>{
    body.append(elem('p',sourceType==='video'?'Your browser automatically selects the available quality for this video. Select a different feed under Views if the provider offers one.':'The video is on another website. Browsers cannot control its hidden quality menu from this app. Use Site controls or open the original page to change quality.','cs-help'));
    body.append(action('Switch to site controls',()=>{closeDialog();sourceControls()}));body.append(action('Open original site ↗',()=>window.open(streamUrl,'_blank','noopener,noreferrer')));
  })}
  function dualMode(){if(dual){second?.remove();surfaceB.replaceChildren();second=null;dual=false;root.classList.remove('cs-dual');surfaceB.hidden=true;return}
    dialog('Dual stream',body=>{
      body.append(elem('p','Both streams can display together. With protected third-party embeds, the browser cannot independently mute one feed. For two direct videos, the second is muted by default.','cs-help'));
      const field=elem('input');field.placeholder='Paste another HTTPS video or stream page';field.type='url';body.append(field);
      body.append(action('Start dual stream',()=>{if(!allowedUrl(field.value.trim()))return hint('Enter a valid HTTPS URL');second=createMedia(surfaceB,field.value.trim());if(second instanceof HTMLVideoElement)second.muted=true;dual=true;surfaceB.hidden=false;root.classList.add('cs-dual');closeDialog()},'cs-primary'));
    })
  }
  // Gesture logic: single tap toggles, double tap seeks, long-press is 2x only on HTML5 videos.
  const touch=$('csTouch');
  touch.addEventListener('pointerdown',e=>{
    downX=e.clientX;downY=e.clientY;gestureMoved=false;clearTimeout(holdTimeout);
    if(pauseAvailable())holdTimeout=setTimeout(()=>{if(mode==='full'&&!gestureMoved){holdActive=true;originalSpeed=primary.playbackRate;primary.playbackRate=2;hint('2× SPEED');}},480);
  });
  touch.addEventListener('pointermove',e=>{if(Math.abs(e.clientX-downX)>12||Math.abs(e.clientY-downY)>12){gestureMoved=true;clearTimeout(holdTimeout)}});
  const endGesture=e=>{
    clearTimeout(holdTimeout);
    if(holdActive){if(pauseAvailable())primary.playbackRate=originalSpeed;holdActive=false;return}
    if(gestureMoved)return;
    const now=Date.now(),x=e.clientX||downX;
    if(now-lastTap<310&&Math.abs(lastTapX-x)<Math.max(50,innerWidth*.20)){
      clearTimeout(tapTimeout);tapTimeout=null;lastTap=0;
      if(/replay/i.test($('csType').textContent)){seek(x>innerWidth/2?10:-10)}
      else hint('Double tap seeking is available for replays');
    }else {lastTap=now;lastTapX=x;tapTimeout=setTimeout(()=>{showControls(!show)},315)}
  };
  touch.addEventListener('pointerup',endGesture);touch.addEventListener('pointercancel',()=>{clearTimeout(holdTimeout);if(holdActive&&pauseAvailable())primary.playbackRate=originalSpeed;holdActive=false});
  // Buttons and lifecycle
  $('csBack').onclick=mini;$('csMinimize').onclick=mini;$('csMiniExpand').onclick=full;$('csMiniClose').onclick=close;$('csMiniPause').onclick=togglePause;$('csMiniPip').onclick=pip;
  $('csPip').onclick=pip;$('csOpenFloating').onclick=()=>window.open(streamUrl,'_blank','noopener,noreferrer');$('csOpen').onclick=()=>window.open(streamUrl,'_blank','noopener,noreferrer');$('csSourceControls').onclick=sourceControls;
  $('csTogglePlay').onclick=togglePause;$('csView').onclick=showViews;$('csQuality').onclick=quality;
  $('csFit').onclick=()=>{const fill=root.classList.toggle('cs-fill');$('csFit').querySelector('span').textContent=fill?'Fill':'Fit'};
  $('csDual').onclick=dualMode;$('csFull').onclick=async()=>{
    if(document.fullscreenElement){await document.exitFullscreen().catch(()=>{});return}
    try {if(root.requestFullscreen)await root.requestFullscreen({navigationUI:'hide'});else if(pauseAvailable()&&primary.webkitEnterFullscreen)primary.webkitEnterFullscreen();else hint('This browser uses its own fullscreen controls')} catch{hint('Use your browser fullscreen or rotate your phone')}
  };
  $('csSeek').oninput=()=>{if(pauseAvailable()&&Number.isFinite(primary.duration))primary.currentTime=Number($('csSeek').value)*primary.duration/1000};
  $('csDialogClose').onclick=closeDialog;$('csDialog').addEventListener('click',e=>{if(e.target===$('csDialog'))closeDialog()});
  document.addEventListener('keydown',e=>{
    if(e.key!=='Escape'&&e.key!=='Backspace')return;
    if(!$('csDialog').hidden){e.preventDefault();closeDialog();return}
    if(mode==='full'){e.preventDefault();mini()}else if(mode==='mini'){e.preventDefault();pip()}
  });
  // The web platform may block entering PiP without a direct user gesture.
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&mode==='mini'&&pauseAvailable()&&!document.pictureInPictureElement){try{if(primary.requestPictureInPicture)primary.requestPictureInPicture().catch(()=>{});else if(primary.webkitSupportsPresentationMode?.('picture-in-picture'))primary.webkitSetPresentationMode('picture-in-picture')}catch(e){}}});
  let miniY=0;
  $('csMiniBar').addEventListener('pointerdown',e=>{miniY=e.clientY});
  $('csMiniBar').addEventListener('pointerup',e=>{if(e.clientY-miniY>65)close()});
  window.CourtsideWeb={open,resume,close,mini,full,pip,getMode:()=>mode};
  if(saved()?.url)window.showResume?.(true);
})();
